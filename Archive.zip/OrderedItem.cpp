#include "OrderedItem.h"

OrderedItem::~OrderedItem() { }
