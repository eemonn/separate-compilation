#pragma once

class ListItem {
public:
        virtual ~ListItem();
}; // class ListItem
